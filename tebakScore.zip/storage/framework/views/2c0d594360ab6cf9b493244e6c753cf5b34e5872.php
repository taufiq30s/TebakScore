<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">Manage Team</div>
        <div class="card-body">
          <a href="team/add" class="btn btn-primary">Tambah Team</a>
          <br><br>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Id Tim</th>
                <th scope="col">Nama Tim</th>
                <th scope="col">League Tim</th>
                <th scope="col">Tipe Tim</th>
                <th scope="col" colspan="2">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($team->idTeam); ?></td>
                <td><?php echo e($team->nameTeam); ?></td>
                <td><?php echo e($team->leagueTeam); ?></td>
                <td><?php echo e($team->typeTeam); ?></td>
                <td>
                  <a href="<?php echo e(action('TeamController@edit', $team['idTeam'])); ?>" class="btn btn-warning btn-sm">Edit</a>
                </td>
                <td>
                  <form class="delete" onsubmit="return confirm('Anda yakin ingin menghapus tim ini?');" action="<?php echo e(action('TeamController@destroy', $team['idTeam'])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE">
                    <input class="btn btn-danger btn-sm" type="submit" value="Hapus">
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mtaufiq/workplace/tebakScore/resources/views/admin/team/index.blade.php ENDPATH**/ ?>