<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <a href="/admin/member" class="row">Manage Member</a>
                    <a href="/admin/team" class="row">Manage Team</a>
                    <a href="/admin/match" class="row">Manage Match</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mtaufiq/workplace/tebakScore/resources/views/adminHome.blade.php ENDPATH**/ ?>