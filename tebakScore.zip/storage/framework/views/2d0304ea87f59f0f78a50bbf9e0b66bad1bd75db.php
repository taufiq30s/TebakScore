<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">Manage Team</div>
        <div class="card-body">
          <?php if(!isset($team->idTeam)): ?>
          <form action="/admin/team" method="post">
          <?php else: ?>
          <form action="/admin/team/<?php echo e($team->idTeam); ?>" method="post">
          <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label for="namaTeam" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Tim')); ?></label>
              <div class="col-md-6">
                <input type="namaTeam" id="namaTeam" class="form-control <?php echo e($errors->has('namaTeam') ? ' is-invalid' : ''); ?>" name="namaTeam" value="<?php echo e($team->nameTeam); ?>" required>
                <?php if($errors->has('namaTeam')): ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($errors->first('namaTeam')); ?></strong>
                </span>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group row">
              <label for="leagueTeam" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Liga Tim')); ?></label>
              <div class="col-md-6">
                <input type="leagueTeam" id="leagueTeam" class="form-control <?php echo e($errors->has('leagueTeam') ? ' is-invalid' : ''); ?>" name="leagueTeam" value="<?php echo e($team->leagueTeam); ?>"  required>
                <?php if($errors->has('leagueTeam')): ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($errors->first('leagueTeam')); ?></strong>
                </span>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group row">
              <label for="typeTeam" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipe Tim')); ?></label>
              <div class="col-md-6">
                <input type="typeTeam" id="typeTeam" class="form-control <?php echo e($errors->has('typeTeam') ? ' is-invalid' : ''); ?>" name="typeTeam" value="<?php echo e($team->typeTeam); ?>"  required>
                <?php if($errors->has('typeTeam')): ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($errors->first('typeTeam')); ?></strong>
                </span>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group row mb-0">
              <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                  <?php if(!isset($team->idTeam)): ?>
                  <?php echo e(__('Tambah')); ?>

                  <?php else: ?>
                  <?php echo e(__('Edit')); ?>

                  <?php endif; ?>
                </button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">Kembali</a>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mtaufiq/workplace/tebakScore/resources/views//admin/team/form.blade.php ENDPATH**/ ?>