<div class="jumbotron mb-0">
  <div class="container">
    <div class="row">
      <div class="col col-md-5">
        <h1 class="display-5">Tebak Score Terbaik</h1>
        <p class="lead">Selamat Memprediksi Score</p>
      </div>
      <div class="col col-md-7 bg-primary">
        Iklan
      </div>
    </div>
  </div>
</div>
